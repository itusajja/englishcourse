// Import required modules
const express = require('express');
const session = require("express-session");
const { create } = require('express-handlebars');
const bodyParser = require("body-parser");
const morgan = require('morgan');
const cors = require('cors');
const multer = require('multer');
const socketIo = require('socket.io');
const path = require('path');
const http = require('http');
const fs = require('fs');
const fsp = require('fs').promises;
const { spawn } = require('child_process');
const md5 = require('md5');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const baseRoutes = require('./routes');
const errorMiddleware = require('./middlewares/errorMiddleware');
const notFoundMiddleware = require('./middlewares/notFoundMiddleware');

const {
    getPlatform,
    getBrowser,
    getData,
    saveToFile,
    generateUniqueId,
} = require('./helpers/helpers');

const app = express();
const PORT = process.env.PORT || 9000;
const server = http.createServer(app);
const io = socketIo(server);

app.use(morgan('dev'));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.json());

app.engine('handlebars', create({
    helpers: {
        isEqual: (a, b, options) => {
            return a === b ? options.fn(this) : options.inverse(this);
        },
        json: (context) => {
            return JSON.stringify(context); // Convert the object to a JSON string
        },
        isCorrect: (a, b, c, d, options) => {
            if (a===b && c===d) {
                return options.fn(this);
            } else {
                return options.inverse(this);
            }
        }
    },
    partialsDir: path.join(__dirname, 'views/partials'),
}).engine);
app.set('view engine', 'handlebars');
app.set('views', './views');

app.use(
    session({
        secret: "panic-button-secretkey",
        resave: false,
        saveUninitialized: false,
        cookie: {
            secure: false,
            maxAge: 1000 * 60 * 30 * 2,
            httpOnly: true,
        },
    })
);

app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy({
    usernameField: 'pin', // Look for 'pin' instead of 'username'
    passwordField: 'password', // We don't have a password field, so it's set to false
    passReqToCallBack: true
}, async (pin, password, done) => {
    let security = await getData('security')

    let user = security.filter(e => e.pin === md5(pin))
    if (user.length) {
        return done(null, user[0]);
    } else {
        return done(null, false, { message: 'Invalid PIN' });
    }
}));

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    let security = await getData('security')
    let user = security.find(e => e.id === id);
    done(null, user);
});

app.set('isPlayerOn', 'OFF');
app.set('connectedClients', []);

app.use('/public', express.static(path.join(__dirname, 'public')));
app.get('/socket.io/socket.io.js', (req, res) => {
    res.sendFile(path.join(__dirname, 'node_modules/socket.io/client-dist/socket.io.js'));
});

app.use((req, res, next) => {
    req.io = io;
    // console.log(req.session, "req.session");
    // console.log(req.user, "req.user");
    // console.log(`${req.method} ${req.url} - ${new Date().toISOString()}`);
    next();
});

app.use('/', baseRoutes);
app.use(errorMiddleware);
app.use(notFoundMiddleware);

io.on('connection', (socket) => {
    const isAdmin = socket.handshake.query.admin;
    if (isAdmin) { return; }
    const fingerprint = socket.handshake.query.fp;
    const timezone = socket.handshake.query.timezone;

    const userDetails = {
        id: socket.id,
        userAgent: socket.request.headers['user-agent'],
        ip: socket.handshake.address,
        platform: getPlatform(socket.request.headers['user-agent']),
        browser: getBrowser(socket.request.headers['user-agent']),
        deviceName: socket.handshake.query.deviceName || 'Unknown Device',
        user: socket.handshake.query.group || 'Guest',
        fingerprint: fingerprint,
        timezone: timezone,
    };

    let connectedClients = app.get('connectedClients');
    connectedClients.push(userDetails);
    app.set('connectedClients', connectedClients);
    saveToFile('clients', connectedClients);
    io.emit('connectedClients', `${connectedClients.length} Online`);

    socket.on('disconnect', () => {
        connectedClients = app.get('connectedClients');
        connectedClients = connectedClients.filter(client => client.id !== socket.id);
        app.set('connectedClients', connectedClients);
        saveToFile('clients', connectedClients);
        io.emit('connectedClients', `${connectedClients.length} Online`);
    });
});

server.listen(PORT, () => {
    console.log(`Server is running on pert ${PORT}`);
});