// authMiddleware.js
const authMiddleware = (req, res, next) => {
    if (!req.isAuthenticated()) {
        // If the user is not authenticated, proceed to the login page
        return res.redirect('/pb-admin/login');
    }
    next(); // Proceed to the protected route if authenticated
};

// For the login page, prevent authenticated users from accessing it
const preventLoginIfAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        // If the user is logged in, redirect them to the home page or dashboard
        return res.redirect('/pb-admin');
    }
    next(); // Proceed to the login page if not authenticated
};

module.exports = { authMiddleware, preventLoginIfAuthenticated };
