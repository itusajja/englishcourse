const authMiddleware = (req, res, next) => {
    const apiKey = req.headers['x-api-key'];
    if (apiKey === '41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831') {
        next();
    } else {
        res.status(401).json({ message: 'Unauthorized' });
    }
};



module.exports = authMiddleware;
