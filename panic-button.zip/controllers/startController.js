exports.mainPage = (req, res) => {
    const isPlayerOn = req.app.get('isPlayerOn');
    res.render('base', { 
        layout: false, // Disable the default layout
        title: 'Selamat Datang di aplikasi Panic Button!', 
    });
};