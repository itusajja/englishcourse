const passport = require('passport');

exports.login = (req, res) => {
    res.render('login', {
        layout: false,
        title: 'Panic Button | Admin Site',
    });
};

exports.auth = (req, res, next) => {
    console.log('Request Body:', req.body);
    passport.authenticate('local', {
    successRedirect: '/dashboard',  // Redirect to the dashboard after successful login
    failureRedirect: '/login',      // Redirect to login page on failure
    failureFlash: true              // Enable flash messages on failure
}, (err, user, info) => {
        if (err) {
            console.log("HENE")
            return next(err);
        }
        if (!user) {
            console.log("HENE1")
            return res.status(401).json({ message: info.message || 'Invalid PIN', success: false });
        }

        req.login(user, (err) => {
            if (err) {
                return next(err);
            }
            res.status(200).json({ message: 'Login successful', success: true, user });
        });
    })(req, res, next);
};