const {
    getPlatform,
    getBrowser,
    saveToFile,
    generateUniqueId,
    removeData,
    getData,
} = require('../helpers/helpers');
const path = require('path');
const { spawn } = require('child_process');
const multer = require('multer');
const md5 = require('md5');

exports.mainPage = (req, res) => {
    exports.createDefaultSetting()
    res.render('base', {
        layout: false, // Disable the default layout
        title: 'Selamat Datang di aplikasi Panic Button!',
    });
};

exports.userPage = async (req, res) => {
    let setting = await getData('setting')
    let pb_map_setting = setting.pb_map_setting;

    if(setting.pb_map_setting_grantedlist.includes(req.params.id)){
        pb_map_setting = 'on'
    }
    if(setting.pb_map_setting_restrictedlist.includes(req.params.id)){
        pb_map_setting = 'off'
    }
    
    res.render('panic-button', {
        layout: false, // Disable the default layout
        title: 'Selamat Datang di aplikasi Panic Button!',
        userid: req.params.id,
        pb_map_setting: pb_map_setting,
    });
};

exports.numberOfConnect = async (req, res) => {
    let data = await getData('emergency')
    res.send(`Connected devices: ${data.length}`);
};

exports.playerStatus = (req, res) => {
    const isPlayerOn = req.app.get('isPlayerOn');
    res.send(`Player is ${isPlayerOn}`);
};

exports.checkGroups = async (req, res) => {
    const id = req.params.id;
    let data = await getData('users')
    if (data.filter(e => e.uuid == id).length <= 0) {
        res.status(200).json({ ok: false, message: "Data empty", success: false });
    } else {
        let user = data.find(e => e.uuid == id)
        let userlocation = await getData('userlocation', user.uuid)
        user.location = userlocation.location
        res.status(200).json({ ok: true, user: user, message: "Data exist", success: true });
    }
}

exports.updateLocation = async (req, res) => {
    const { location } = req.body; // Extract pin from request body
    const id = req.params.id;
    let data = await getData('userlocation', id)


    let newLocation = []
    for (let i = 0; i < data.addresses.length; i++) {
        if (i <= 0) {
            newLocation.push(data.addresses[i])
        }
    }
    if (newLocation.length == 1) {
        newLocation.push(location)
    }
    data.addresses = newLocation
    data.location = newLocation[newLocation.length - 1]

    saveToFile('userlocation', data, id)
    req.io.emit('updateLocation', 'new');
    res.status(200).json({ ok: true, message: "Data Updated", success: true });
};

exports.createDefaultSetting = async (req, res) => {
    let data = await getData('setting')
    let security = await getData('security')
    if (!Object.keys(data).length) {
        data = {
            location: [12541966.68, -890888.68]
        }
        saveToFile('setting', data);
    }
    if (!security.length) {
        security = [{
                id: 1,
                level: 99,
                name: "Owner",
                pin: md5("0000")
            },
            {
                id: 10,
                level: 40,
                name: "Staff",
                pin: md5("1234")
            }
        ]
        saveToFile('security', security);
    }
    // res.status(200).json({ ok: true, message: "Data updated", success: true });
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/audio/');
    },
    filename: async (req, file, cb) => {
        const customFilename = req.body.customFilename || Date.now();
        const ext = path.extname(file.originalname);

        let data = await getData('users')
        let current = data.find(e => e.uuid == req.body.customFilename.split(".")[0])
        current.audio = `${customFilename}${ext}`
        saveToFile('users', data)
        cb(null, `${customFilename}${ext}`);
    },
});

const upload = multer({
    storage: storage,
    // limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('audio/')) {
            cb(null, true);
        } else {
            cb(new Error('Only audio files are allowed!'), false);
        }
    },
});

exports.uploadAudio = async (req, res) => {
    // Handle file upload with multer
    upload.single('audioFile')(req, res, (err) => {
        if (err instanceof multer.MulterError) {
            // Handle multer-specific errors (e.g., file size limit exceeded)
            return res.status(413).send('File size exceeds the allowed limit.');
        } else if (err) {
            // Handle other errors
            return res.status(400).send(err.message);
        }

        if (!req.file) {
            return res.status(400).send('No file uploaded or invalid file type.');
        }

        // Send success response
        res.send(`Audio uploaded successfully as ${req.file.filename}`);
    });
}

exports.playAudio = async (req, res) => {
    const id = req.params.id;
    if (!id) {
        return res.write('Player is OFF');
    }
    let data = await getData('users');
    let current = data.find(e => e.uuid == id)

    let userlocation = await getData('userlocation', current.uuid)
    current.location = userlocation.location

    let isPlayerOn = req.app.get('isPlayerOn');
    if (isPlayerOn === 'OFF') {
        let emergency = await getData('emergency')
        let check = emergency.filter(e => e.who == current.uuid).length

        let person = {
            details: current,
            who: current.uuid,
            when: [new Date()],
            where: current.location,
            timestamp:new Date(),
            times: 1,
        }
        if (check) {
            emergency.find(e => e.who == current.uuid).timestamp = new Date()
            emergency.find(e => e.who == current.uuid).where = current.location
            emergency.find(e => e.who == current.uuid).when.push(new Date())
            emergency.find(e => e.who == current.uuid).times += 1
        } else {
            emergency.push(person)
        }
        saveToFile('emergency', emergency);

        req.io.emit('emergency', 'GAWAT');
        req.app.set('isPlayerOn', 'ON');

        const filePath = path.join(__dirname, '..', 'public', 'audio', current.audio); // Path to your audio file
        const player = spawn('mpv', ['--no-video', filePath]);

        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        player.stdout.on('data', (data) => {
            res.write(data.toString());
        });
        player.stderr.on('data', (data) => {
            res.write(data.toString());
        });

        player.on('close', (code) => {
            req.app.set('isPlayerOn', 'OFF');
            req.io.emit('emergency', 'UDAH GAWAT NYA');
            req.io.emit('audioFinished', { message: 'Audio playback has finished.' });
            res.write('event: done\n');
            res.write('data: Playback finished\n\n');
            res.end();
        });

        player.on('error', (err) => {
            req.app.set('isPlayerOn', 'OFF');
            req.io.emit('emergency', 'UDAH GAWAT NYA');
            req.io.emit('audioFinished', { message: 'Audio playback has finished.' });
            res.write('event: error\n');
            res.write(`data: ${err.message}\n\n`);
            res.end();
        });
    } else {
        res.send(`Player is on`);
    }
};