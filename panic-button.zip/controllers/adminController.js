const {
    getPlatform,
    getBrowser,
    saveToFile,
    generateUniqueId,
    removeData,
    getData,
} = require('../helpers/helpers');
const md5 = require('md5');

exports.dashboard = async (req, res) => {
    let setting = await getData('setting')
    res.render('admin-dashboard', {
        title: 'Panic Button | Admin Site',
        user: req.user,
        page: 'dashboard',
        setting: setting,
        session: req.user,
    });
};

exports.users = async (req, res) => {
    let setting = await getData('setting')
    if (req.user.id > 1) {
        if (setting.staff_view_users === 'off') {
            return res.redirect('/pb-admin');
        }
    }

    res.render('admin-users', {
        title: 'Panic Button | Admin Site',
        user: req.user,
        page: 'users',
        setting: setting,
        session: req.user,
    });
};

exports.setting = async (req, res) => {
    let users = await getData('users')
    let setting = await getData('setting')
    if (req.user.id > 1) {
        if (setting.staff_view_setting === 'off') {
            return res.redirect('/pb-admin');
        }
    }
    res.render('admin-setting', {
        title: 'Panic Button | Admin Site',
        user: req.user,
        page: 'setting',
        users: users,
        setting: setting,
        session: req.user,
    });
};

exports.security = async (req, res) => {
    let setting = await getData('setting')
    if (req.user.id > 1) {
        if (setting.staff_account_changepin === 'off') {
            return res.redirect('/pb-admin');
        }
    }
    res.render('admin-security', {
        title: 'Panic Button | Admin Site',
        user: req.user,
        session: req.user,
        page: 'security',
        setting: setting
    });
};

exports.getGroups = async (req, res) => {
    let data = await getData('users')
    let clients = await getData('clients')
    for (let current of data) {
        let detailAddrs = await getData('userlocation', current.uuid)
        current.devices = clients.filter(e=> e.user == current.uuid)
        current.location = detailAddrs.location
        current.addresses = detailAddrs.addresses
    }
    res.status(200).json({ users: data });
}

exports.getSetting = async (req, res) => {
    let data = await getData('setting')
    data.user = req.user
    res.status(200).json(data);
}

exports.getEmergencies = async (req, res) => {
    let data = await getData('emergency')
    res.status(200).json({ emergencies: data });
}

exports.removeEmergency = async (req, res) => {
    const id = req.params.id;
    let data = await getData('emergency')

    if (data.filter(e => e.who == id).length <= 0) {
        res.status(200).json({ ok: false, message: "No data.", success: false });
    } else {
        removeData('emergency', 'who', id)
        res.status(200).json({ ok: true, message: "Data Removed", success: true });
    }
};

exports.removeGroup = async (req, res) => {
    const id = req.params.id;
    let data = await getData('users')

    if (data.filter(e => e.uuid == id).length <= 0) {
        res.status(200).json({ ok: false, message: "No data.", success: false });
    } else {
        removeData('users', 'uuid', id)
        res.status(200).json({ ok: true, message: "Data Removed", success: true });
    }
};

exports.updateLocation = async (req, res) => {
    const { location } = req.body; // Extract pin from request body
    const id = req.params.id;
    let data = await getData('userlocation', id)

    data.addresses[0] = location
    data.location = location
    saveToFile('userlocation', data, id)

    res.status(200).json({ ok: true, message: "Data Updated", success: true });
};

exports.updatePIN = async (req, res) => {
    const { pin } = req.body; // Extract pin from request body
    const id = req.params.id;
    let security = await getData('security')
    console.log(security, id, pin)
    security.find(e => e.id == id).pin = md5(pin)
    saveToFile('security', security)
    res.status(200).json({ ok: true, message: "Data Updated", success: true });
};

exports.updateSetting = async (req, res) => {
    const { setting } = req.body;
    let settingdata = await getData('setting')

    settingdata = setting
    saveToFile('setting', settingdata)
    req.io.emit('updateSetting', 'new');
    res.status(200).json({ ok: true, message: "Data Updated", success: true });
};

exports.setDefaultLocation = async (req, res) => {
    const { index } = req.body; // Extract pin from request body
    const id = req.params.id;
    let data = await getData('userlocation', id)

    data.location = data.addresses[index]
    saveToFile('userlocation', data, id)

    res.status(200).json({ ok: true, message: "Data Updated", success: true });
};

exports.removeLocation = async (req, res) => {
    const { index } = req.body; // Extract pin from request body
    const id = req.params.id;
    let data = await getData('userlocation', id)

    data.location = data.addresses[0]
    data.addresses = [data.addresses[0]]
    saveToFile('userlocation', data, id)

    res.status(200).json({ ok: true, message: "Data Updated", success: true });
};

exports.createUser = async (req, res) => {
    const { group } = req.body;
    let setting = await getData('setting')
    let data = await getData('users')

    if (data.filter(e => e.group == group).length <= 0) {
        let userid = generateUniqueId()
        data.push({
            uuid: userid,
            group: group,
        })
        let location = {
            location: setting.location,
            addresses: [setting.location],
        }
        saveToFile('users', data)
        saveToFile('userlocation', location, userid)
        res.status(200).json({ ok: true, message: "Data created", success: true });
    } else {
        res.status(200).json({ ok: false, message: "Data exist", success: false });
    }
};

exports.logout = (req, res) => {
    req.logout((err) => {
        if (err) {
            return res.status(500).send('Logout failed');
        }
        req.session.destroy((err) => {
            if (err) {
                return res.status(500).send('Session destroy failed');
            }
            res.redirect('/pb-admin/login');
        });
    });
};