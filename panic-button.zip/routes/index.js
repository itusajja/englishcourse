const express = require('express');
const router = express.Router();

const baseRoutes = require('./base');
const adminRoutes = require('./admin');
const startRoutes = require('./start');
// const productRoutes = require('./products');

// Mount routes
router.use('/', baseRoutes);
router.use('/pb-admin', adminRoutes);
router.use('/start', startRoutes);
// router.use('/products', productRoutes);

module.exports = router;
