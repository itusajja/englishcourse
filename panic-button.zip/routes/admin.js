const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController');
const adminController = require('../controllers/adminController');
const { authMiddleware, preventLoginIfAuthenticated } = require('../middlewares/authMiddleware');

router.get('/login', preventLoginIfAuthenticated, loginController.login);
router.post('/auth', loginController.auth);

router.use(authMiddleware); // Only logged-in users can access the following routes

router.get('/', adminController.dashboard);
router.get('/users', adminController.users);
router.get('/security', adminController.security);
router.get('/setting', adminController.setting);

router.post('/logout', adminController.logout);

/*API*/
router.get('/get-groups', adminController.getGroups);
router.get('/get-setting', adminController.getSetting);
router.get('/get-emergencies', adminController.getEmergencies);

router.post('/create-user/:id', adminController.createUser);
router.post('/update-location/:id', adminController.updateLocation);
router.post('/update-setting', adminController.updateSetting);
router.post('/update-pin/:id', adminController.updatePIN);
router.post('/setdefault-location/:id', adminController.setDefaultLocation);
router.post('/remove-location/:id', adminController.removeLocation);

router.post('/remove-live/:id', adminController.removeEmergency);
router.post('/remove-group/:id', adminController.removeGroup);


module.exports = router;
