const express = require('express');
const router = express.Router();
const baseController = require('../controllers/baseController');

router.get('/', baseController.mainPage);
router.get('/pb/:id', baseController.userPage);

router.get('/play-audio/:id', baseController.playAudio);

router.get('/check-group/:id', baseController.checkGroups);
router.get('/noc', baseController.numberOfConnect);
router.get('/ps', baseController.playerStatus);

router.post('/upload', baseController.uploadAudio);
router.post('/update-location/:id', baseController.updateLocation);

module.exports = router;
