const express = require('express');
const router = express.Router();
const startController = require('../controllers/startController');
// const authMiddleware = require('../middlewares/authMiddleware');

// router.use(authMiddleware);

router.get('/', startController.mainPage);

module.exports = router;
