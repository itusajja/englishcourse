const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const paths = {
    'clients': path.join(__dirname, '..', 'config', 'clients.json'),
    'users': path.join(__dirname, '..', 'config', 'users.json'),
    'emergency': path.join(__dirname, '..', 'config', 'emergency.json'),
    'setting': path.join(__dirname, '..', 'config', 'setting.json'),
    'security': path.join(__dirname, '..', 'config', 'security.json'),
    'userlocation': (user)=>{return path.join(__dirname, '..', 'config', 'locations', user+'.json')},
}

const getPlatform = (userAgent) => {
    if (userAgent.includes('Windows NT')) {
        return 'Windows';
    } else if (userAgent.includes('Mac OS X')) {
        return 'MacOS';
    } else if (userAgent.includes('Linux')) {
        return 'Linux';
    } else {
        return 'Unknown';
    }
};

const getBrowser = (userAgent) => {
    if (userAgent.includes('Chrome')) {
        return 'Chrome';
    } else if (userAgent.includes('Firefox')) {
        return 'Firefox';
    } else if (userAgent.includes('Safari')) {
        return 'Safari';
    } else {
        return 'Unknown';
    }
};

const generateUniqueId = () => {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 12)}`;
};

const saveToFile = (type, value, param='') => {
    if (paths[type]) {
    	if(param != ''){
    		fs.writeFile(paths[type](param), JSON.stringify(value, null, 2), (err) => {
	            if (err) {
	                console.error(`Error saving connected ${path} to file:`, err);
	            } else {
	                console.log(`File saved to ${path}`);
	            }
	        });
    	}else{
	        fs.writeFile(paths[type], JSON.stringify(value, null, 2), (err) => {
	            if (err) {
	                console.error(`Error saving connected ${path} to file:`, err);
	            } else {
	                console.log(`File saved to ${path}`);
	            }
	        });
    	}
    }
};

const getData = async (type, param='') => {
    if (paths[type]) {
    	if(param != ''){
    		try {
	        	const file = await fsp.readFile(paths[type](param), 'utf8');
	            return JSON.parse(file);
	        } catch (e) {
	            return []
	        }
    	}else{
	        try {
	        	const file = await fsp.readFile(paths[type], 'utf8');
	            return JSON.parse(file);
	        } catch (e) {
	            return []
	        }
    	}
    } else {
        return [];
    }
}

const delay = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

const removeData = async (type, field, id, param='') => {
    if (paths[type]) {
    	if(param != ''){
    		let data = await getData(type, param)
	        data = data.filter(e => e[field] !== id)
	        saveToFile(type, data, param)
    	}else{
	        let data = await getData(type)
	        data = data.filter(e => e[field] !== id)
	        saveToFile(type, data)
    	}
    }
};



module.exports = {
    getPlatform,
    getBrowser,
    saveToFile,
    generateUniqueId,
    delay,
    getData,
    removeData
};