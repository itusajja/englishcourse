    $('.select2').select2()

    $('input[type="checkbox"]').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
    })

    $('input[type="checkbox"]').on('ifChanged', function(event) {
        const isChecked = $(this).prop('checked'); // Get the checked state
        const newValue = isChecked ? 'on' : 'off'; // Set the custom value
        $(this).val(newValue); // Update the value dynamically
    });

    $('input[type="checkbox"]').on('ifClicked', function(event) {
        const type = $(this).attr('type');
        const checked = $(this).prop('checked');
        const label = $(this).closest('th').find('label');

        if (type === 'checkbox') {
            if (!checked) {
                label.html(' Aktif')
            } else {
                label.html(' Non-Aktif')
            }
        }
    });

    async function getSetting() {
        let setting = window.pageSetting
        let convert = ol.proj.toLonLat(setting.location)
        $('[name=lat]').val(convert[1])
        $('[name=lon]').val(convert[0])

        $("#avoid").val(setting.pb_map_setting_restrictedlist).change();
        $("#allow").val(setting.pb_map_setting_grantedlist).change();

        for (let cb of document.querySelectorAll('input[type=checkbox]')) {
            if (setting[cb.name] === "on") {
                $(cb).prop('checked', 'checked');
            }
        }
    }

    setTimeout(() => {
        getSetting()
    }, 500)

    async function saveSetting() {
        let opts = {}
        for (let cb of document.querySelectorAll('input[type=checkbox]')) {
            opts[cb.name] = (cb.value === 'on') ? 'on' : 'off'
        }

        opts.pb_map_setting_restrictedlist = $("#avoid").val()
        opts.pb_map_setting_grantedlist = $("#allow").val()
        let location = ol.proj.fromLonLat([$('[name=lon]').val(), $('[name=lat]').val()])
        opts.location = location

        const payload = {
            setting: opts,
        };
        try {
            const response = await fetch("/pb-admin/update-setting/", {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key": "41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();

            if (data.ok) {
                showSnackbar(data.message)

            } else {
                showSnackbar(data.message)
                console.error("Failed to saveSetting", response.statusText);
            }
        } catch (error) {
            console.error("Error during saveSetting:", error);
        }
    }