window.pageSetting = {}
async function getSetting() {
    try {
        const response = await fetch("/pb-admin/get-setting", {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": "41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
            },
        });
        window.pageSetting = await response.json();

        if(window.pageSetting.user.id >1){
            if(window.pageSetting.staff_account_changepin === 'on'){
                document.querySelector('#securityMenu').parentElement.classList.remove('hidden')
            }
            if(window.pageSetting.staff_view_users === 'on'){
                document.querySelector('#usersMenu').parentElement.classList.remove('hidden')
            }
            if(window.pageSetting.staff_view_setting === 'on'){
                document.querySelector('#settingMenu').parentElement.classList.remove('hidden')
            }
        }else{
            document.querySelector('#usersMenu').parentElement.classList.remove('hidden')
            document.querySelector('#securityMenu').parentElement.classList.remove('hidden')
            document.querySelector('#settingMenu').parentElement.classList.remove('hidden')
        }

    } catch (error) {
        console.error("Error during createGroup:", error);
    }
}

getSetting()

const urlParams = new URLSearchParams(window.location.search);
    const menu = urlParams.get('menu');

    if (menu) {
        openMenu(menu)
        console.log(menu)
    }
    const socket = io({
        query: {
            admin: true,
        }
    });

    socket.on('emergency', (data) => {
        if (data === 'GAWAT') {
            getLives()
        } else {
            // stopAudioRings()
        }
    });

    socket.on('audioFinished', (data) => {
        // stopAudioRings()
    });


    $(document).ready(function() {
        $('.sidebar-menu').tree()
    })

    async function signUserOut() {
        try {
            const response = await fetch("/pb-admin/logout", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                }
            });
            if (response.ok) {
                // Redirect to the login page after logout
                window.location.reload()
            } else {
                console.error("Failed to logout", response.statusText);
                alert("Failed to logout. Please try again.");
            }
        } catch (error) {
            console.error("Error during logout:", error);
            alert("An error occurred. Please try again.");
        }
    }


    function openMenu(param) {
        document.querySelectorAll('.sidebar-menu > li:not(.header)').forEach(e => {
            e.className = "";
        })
        document.querySelectorAll('.page').forEach(e => {
            e.classList.add('hidden');
        })

        document.querySelector('#' + param + 'Menu').parentElement.classList.add('active');
        document.querySelector('.page.' + param).classList.remove('hidden');
    }

    document.body.addEventListener('touchstart', function(e) { e.preventDefault(); });