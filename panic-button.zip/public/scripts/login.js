
let working = false;
document.querySelector(".login").addEventListener("submit", function(e) {
    e.preventDefault();
    if (working) return;
    working = true;

    let pin = document.querySelector('input#pin').value
    if (!pin || pin === '' || pin.length <= 0) {
        showSnackbar("Masukkan PIN!")
        working = false;
        return
    }

    const form = this;
    const stateElement = form.querySelector("button > .state");


    form.classList.add("loading");
    stateElement.textContent = "Memeriksa PIN";

    setTimeout(async function() {
        let status;
        let content;

        const url = "/pb-admin/auth";
        const payload = { 
            pin: pin,
            password: pin,
        };

        try {
            const response = await fetch(url, {
                method: "POST", // HTTP method
                headers: {
                    "Content-Type": "application/json", // Specify JSON content
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify(payload) // Convert payload to JSON string
            });

            // Handle the response
                const data = await response.json(); // Parse JSON response
            if (data.success) {
                status = 'ok';
                content = 'Selamat Datang!';
                window.location.reload()
            } else {
                status = 'invalid';
                content = 'PIN Salah!';
                console.error("Error:", data.status, data.statusText);
            }
        } catch (error) {
            status = 'invalid';
            content = 'Ada kendala pada server!';
            console.error("Fetch error:", error);
        }

        form.classList.add(status);
        stateElement.textContent = content;

        setTimeout(function() {
            stateElement.textContent = "Masuk";
            form.classList.remove(status, "loading");
            working = false;
        }, 2000);

    }, 2000);

});