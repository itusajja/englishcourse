    let defaultCoord = [112.6304, -7.9839];
    let transCoord = ol.proj.fromLonLat(defaultCoord);
    let latestCoord = []
    let latestSelectedUser = {}
    let latestSelectedUserIndex = 0
    let pageSetting = {}

    let mapUser = new ol.Map({
        target: 'mapuser', // The id of the HTML element to render the map in
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM() // Use OpenStreetMap as the base layer
            })
        ],
        view: new ol.View({
            center: transCoord,
            zoom: 12 // Adjust the zoom level to fit Surabaya
        })
    });

    let vsUser = new ol.source.Vector();
    let markerUser = new ol.Feature({
        geometry: new ol.geom.Point(transCoord)
    });

    let markerStyleUser = new ol.style.Style({
        image: new ol.style.Icon({
            anchor: [0.5, 1], // Set anchor to bottom center
            anchorXUnits: 'fraction', // Anchor units are fractions of the image size
            anchorYUnits: 'fraction',
            scale: 0.4,
            src: 'https://maps.google.com/mapfiles/kml/paddle/red-blank.png' // URL to a marker icon image
        })
    });
    markerUser.setStyle(markerStyleUser);

    function addMarkerUser(coords, title) {
        let markerUser = new ol.Feature({
            geometry: new ol.geom.Point(coords),
            name: title
        });
        markerUser.setStyle(markerStyleUser);
        vsUser.addFeature(markerUser);
        return markerUser;
    }

    // Add the primary marker
    let primaryMarkerUser = addMarkerUser(transCoord, 'Lokasi Saya');
    let vectorLayerUser = new ol.layer.Vector({
        source: vsUser
    });

    mapUser.addLayer(vectorLayerUser);

    let tooltipElementsUser = [];
    let overlayUser;
    vsUser.getFeatures().forEach(feature => {
        let tooltipElementUser = document.createElement('div');
        tooltipElementUser.style.top = '-26px';
        tooltipElementUser.style.minWidth = '90px';
        tooltipElementUser.style.fontSize = '12px';
        tooltipElementUser.style.textAlign = 'center';
        tooltipElementUser.style.position = 'absolute';
        tooltipElementUser.style.background = 'white';
        tooltipElementUser.style.padding = '1px 3px';
        tooltipElementUser.style.border = '1px solid black';
        tooltipElementUser.style.transform = 'translate(-50%, -100%)';
        tooltipElementUser.innerHTML = feature.get('name');

        overlayUser = new ol.Overlay({
            element: tooltipElementUser,
            positioning: 'bottom-center',
            stopEvent: false
        });
        mapUser.addOverlay(overlayUser);
        overlayUser.setPosition(feature.getGeometry().getCoordinates());
        tooltipElementsUser.push(tooltipElementUser);
    });

    mapUser.on('click', function(event) {
        const coordinates = event.coordinate;
        latestCoord = coordinates
        movePosition(coordinates)
        document.querySelector('.btnsavemap').classList.remove('hidden')
    });

    function updateMarker(coordinates, updateMarker) {
        movePosition(coordinates)
        tooltipElementsUser[0].innerHTML = updateMarker;
    }

    function movePosition(coordinates) {
        // Validate the coordinates
        if (!Array.isArray(coordinates) || coordinates.length !== 2) {
            alert("Invalid coordinates provided:", coordinates);
            return;
        }

        // Move the primary marker
        primaryMarkerUser.getGeometry().setCoordinates(coordinates);

        // Move the overlay
        overlayUser.setPosition(coordinates);

        // Optionally, center the map view on the new coordinates
        mapUser.getView().setCenter(coordinates);

        console.log(`Marker and overlay moved to: [${coordinates.join(", ")}]`);
    }

    let dataGroup = [];

    async function getGroup() {
        dataGroup = {users:[]}
        renderGroups(dataGroup)
        try {
            const response = await fetch("/pb-admin/get-groups", {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
            });
            dataGroup = await response.json();
            pageSetting = window.pageSetting
            renderGroups(dataGroup)
            if (dataGroup.users.length) {
                selectItem(document.querySelectorAll('.usersData > li.item')[latestSelectedUserIndex], latestSelectedUserIndex)
            }
        } catch (error) {
            console.error("Error during createGroup:", error);
        }
    }
    let newLocations = []

    function renderGroups(data) {
        let output = []
        data.users.sort((a, b) => {
            if (a.group < b.group) return -1;
            if (a.group > b.group) return 1;
            return 0;
        }).forEach((e, i) => {

            let userlink = ((e.audio) ? `<span onclick="openURL('${e.uuid}')" class="label label-success pull-right" style="margin-right:5px">URL Link</span>`:``)
            let remove = `<span onclick="removeGroup('${e.uuid}')" class="label label-danger pull-right">Remove</span>`
            let audio = `<input type="file" onchange="uploadAudio('${e.uuid}')" id="audioInput${e.uuid}" accept="audio/*" style="display:none;"/>
                                        <div style="color:#fff;background: linear-gradient(105deg,#1175ca,#063e6d,#09253e);padding: 0px 9px;border-radius: 5px;" class="product-img" onclick="updateAudio('${e.uuid}')">
                                            <span class="icon">♬</span>
                                        </div>`

            if(pageSetting.user.id > 1){
                if(pageSetting.staff_user_changeaudio == 'off'){
                    audio = `<div style="color:#fff;background: linear-gradient(105deg,#1175ca,#063e6d,#09253e);padding: 0px 9px;border-radius: 5px;" class="product-img">
                                            <span class="icon">👤</span>
                                        </div>`
                }
                if(pageSetting.staff_user_link == 'off'){
                    userlink = ''
                }
                if(pageSetting.staff_user_remove == 'off'){
                    remove = ''
                }
            }

            let item = `<li onclick="selectItem(this, ${i})" class="item ` + ((i == 0) ? 'selected' : '') + `" style="cursor:pointer;padding-left:25px;padding-right:15px">
                                        `+audio+`
                                        <div class="product-info">
                                            <a href="javascript:void(0)" class="product-title">${e.group}
                                                `+remove+`
                                                `+userlink+`
                                            </a>
                                            <span class="product-description">
                                                <audio onplay="checkPlayingAudio(this)" id="audioPreview${e.uuid}" ` + ((e.audio) ? '' : 'class="hidden"') + ` src="` + ((e.audio) ? '/public/audio/' + e.audio : '') + `" controls>
                                                    Your browser does not support the audio element.
                                                </audio>
                                            </span>
                                        </div>
                                    </li>`
            output.push(item)
        })

        if (output.length) {
            document.querySelector('.usersData').innerHTML = output.join("")
            if(document.querySelector('.mapsavail')){
                document.querySelector('.mapsavail').classList.remove('hidden')
            }
            if(document.querySelector('.mapsempty')){
                document.querySelector('.mapsempty').classList.add('hidden')
            }
        } else {
            document.querySelector('.usersData').innerHTML = "No data available."
            if(document.querySelector('.mapsavail')){
                document.querySelector('.mapsavail').classList.add('hidden')
            }
            if(document.querySelector('.mapsempty')){
                document.querySelector('.mapsempty').classList.remove('hidden')
            }
        }
    }

    const formatDate = (dateInput) => {
        // Ensure dateInput is a Date object
        const date = new Date(dateInput);
        if (isNaN(date)) {
            return 'Invalid Date';
        }

        const d = date.getDate().toString().padStart(2, '0'); // Day
        const m = (date.getMonth() + 1).toString().padStart(2, '0'); // Month
        const y = date.getFullYear(); // Year
        const h = date.getHours().toString().padStart(2, '0'); // Hour
        const i = date.getMinutes().toString().padStart(2, '0'); // Minutes
        const s = date.getSeconds().toString().padStart(2, '0'); // Seconds

        return `${d}/${m}/${y} ${h}:${i}:${s}`;
    };

    function selectItem(elm, i) {
        latestCoord = []
        if(document.querySelector('.btnsavemap')){
            document.querySelector('.btnsavemap').classList.add('hidden')
        }
        let current = dataGroup.users.sort((a, b) => {
            if (a.group < b.group) return -1;
            if (a.group > b.group) return 1;
            return 0;
        })[i]
        latestSelectedUser = current
        latestSelectedUserIndex = i

        document.querySelectorAll('.usersData > li.item').forEach(e => {
            e.classList.remove('selected')
        })

        elm.classList.add('selected')
        document.querySelectorAll('.selectedUser').forEach(e =>{
            e.innerHTML = current.group
        })

        if(Object.keys(latestSelectedUser).length){
            // if(JSON.stringify(latestSelectedUser.location) === JSON.stringify(latestSelectedUser.addresses[0])){
            //     document.querySelector('.lokasiutamabtn').classList.add('hidden')
            //     document.querySelector('.lokasiutamalabel').classList.remove('hidden')
            // }else{
            //     document.querySelector('.lokasiutamabtn').classList.remove('hidden')
            //     document.querySelector('.lokasiutamalabel').classList.add('hidden')
            // }

            let userlocations = []
            for (let i = 0; i < latestSelectedUser.addresses.length; i++) {
                let active = (JSON.stringify(latestSelectedUser.addresses[i]) === JSON.stringify(latestSelectedUser.location))
                

                let setDefault = `<span onclick="setDefaultLocation(`+i+`)" class="lokasiutamabtn label label-default pull-right `+(active?'hidden':'')+`"" style="margin-right:5px">Jadikan lokasi utama</span>`
                let removeLocation = ((i==0)?' ':' <span onclick="removeLocation('+i+')" class="label label-danger pull-right" style="margin-right:5px">Hapus</span>')
                if(pageSetting.user.id > 1){
                    if(pageSetting.staff_user_setdefaultlocation == 'off'){
                        setDefault = ''
                    }
                    if(pageSetting.staff_user_removelocation == 'off'){
                        removeLocation = ''
                    }
                }

                let html = `<li `+` onclick="selectItemMap(this, ${JSON.stringify(latestSelectedUser.addresses[i])}, 'Lokasi `+((i==0)?' Default':' Baru')+' '+latestSelectedUser.group+`')" class="item" style="cursor:pointer;">
                                <div style="background-color: #dedede;padding: 0px 5px;border-radius: 5px;" class="product-img" onclick="updateAudio()">
                                                <span class="icon">📍</span>
                                            </div>
                                            <div class="product-info">
                                                <a href="javascript:void(0)" class="product-title">Lokasi `+((i==0)?' Default':' Baru')+` 
                                                    `+removeLocation+`
                                                    `+setDefault+`
                                                    <span class="lokasiutamalabel label label-primary `+(active?'':'hidden')+`" style="margin-right:5px">Utama</span>
                                                </a>
                                                <span class="product-description" style="font-size:12px;font-weight:800">
                                                    Ditambahkan oleh `+((i==0)?' Admin':' Pengguna')+`
                                                </span>
                                            </div>
                                        </li>`

                userlocations.push(html)
            }

            document.querySelector('.usersDataLocations').innerHTML = userlocations.join("")
            // btnsavemap
            // lokasiutamabtn
            // lokasiutamalabel
            if(document.querySelector('.mapsavail')){
                document.querySelector('.mapsavail').classList.remove('hidden')
            }if(document.querySelector('.mapsempty')){
                document.querySelector('.mapsempty').classList.add('hidden')
            }
        }else{
            if(document.querySelector('.mapsavail')){
                document.querySelector('.mapsavail').classList.add('hidden')
            }
            if(document.querySelector('.mapsempty')){
                document.querySelector('.mapsempty').classList.remove('hidden')
            }
        }

        updateMarker(current.location || defaultCoord, `Lokasi ${current.group}`)
    }

    function selectItemMap(elm, coord, title){
        document.querySelectorAll('.usersDataLocations > li.item').forEach(e => {
            e.classList.remove('selected')
        })

        elm.classList.add('selected')
        updateMarker(coord || defaultCoord, title)
    }


    function checkPlayingAudio(audio) {
        const audios = document.querySelectorAll('audio'); // Select all audio elements
        audios.forEach(otherAudio => {
            if (otherAudio !== audio) {
                otherAudio.pause(); // Pause other audios
                otherAudio.currentTime = 0; // Reset their time to start
            }
        });
    }

    function updateAudio(uuid) {
        document.querySelector('#audioInput' + uuid).click()
    }

    async function saveLocation() {
        if (!latestCoord.length) {
            alert("Invalid location")
            return
        }

        const payload = {
            location: latestCoord,
        };
        try {
            const response = await fetch("/pb-admin/update-location/"+latestSelectedUser.uuid, {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();

            if (data.ok) {
                showSnackbar(data.message)
                getGroup();
                latestCoord = []
                // setTimeout(()=>{selectItem(document.querySelectorAll('.usersData > li.item')[latestSelectedUserIndex], latestSelectedUserIndex)},1000)

            } else {
                showSnackbar(data.message)
                console.error("Failed to updateLocation", response.statusText);
                // alert("Failed to createGroup. Please try again.");
            }
        } catch (error) {
            console.error("Error during updateLocation:", error);
            // alert("An error occurred. Please try again.");
        }
    }
    async function setDefaultLocation(i) {
        const payload = {
            index: i,
        };
        try {
            const response = await fetch("/pb-admin/setdefault-location/"+latestSelectedUser.uuid, {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();

            if (data.ok) {
                showSnackbar(data.message)
                getGroup();
                latestCoord = []
            } else {
                showSnackbar(data.message)
                console.error("Failed to setDefaultLocation", response.statusText);
                // alert("Failed to createGroup. Please try again.");
            }
        } catch (error) {
            console.error("Error during setDefaultLocation:", error);
            // alert("An error occurred. Please try again.");
        }
    }


    async function removeLocation(i) {
        const payload = {
            index: i,
        };
        try {
            const response = await fetch("/pb-admin/remove-location/"+latestSelectedUser.uuid, {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();

            if (data.ok) {
                showSnackbar(data.message)
                getGroup();
                latestCoord = []
                // setTimeout(()=>{selectItem(document.querySelectorAll('.usersData > li.item')[latestSelectedUserIndex], latestSelectedUserIndex)},1000)

            } else {
                showSnackbar(data.message)
                console.error("Failed to removeLocation", response.statusText);
                // alert("Failed to createGroup. Please try again.");
            }
        } catch (error) {
            console.error("Error during removeLocation:", error);
            // alert("An error occurred. Please try again.");
        }
    }

    async function uploadAudio(uuid) {
        let audioInput = document.querySelector('#audioInput' + uuid)
        let audioPreview = document.querySelector('#audioPreview' + uuid)
        selectedFile = audioInput.files[0];
        if (selectedFile) {

            const finalFilename = uuid;

            const formData = new FormData();
            formData.append('customFilename', finalFilename); // Send the custom filename
            formData.append('audioFile', selectedFile);

            try {
                const response = await fetch('/upload', {
                    method: 'POST', // Logout is a POST request
                    body: formData,
                });

                if (response.ok) {
                    const result = await response.text();
                    showSnackbar(result); // Display success message from the server
                    getGroup()
                } else {
                    showSnackbar('Failed to upload audio.');
                }
            } catch (error) {
                showSnackbar('An error occurred while uploading the audio.');
            }

            const fileURL = URL.createObjectURL(selectedFile);
            audioPreview.src = fileURL;
            audioPreview.classList.remove('hidden');
        } else {
            audioPreview.classList.add('hidden');
        }


    }

    function openURL(name) {
        window.open('/pb/' + name, '_blank').focus();
    }

    async function removeGroup(uuid) {
        if (!confirm("Apakah ingin menghapus User ini?")) {
            return
        }
        try {
            const response = await fetch("/pb-admin/remove-group/"+uuid, {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify({})
            });
            const data = await response.json();

            if (data.ok) {
                // Redirect to the login page after logout
                group.value = ''
                showSnackbar(data.message)
                latestSelectedUserIndex=0
                getGroup()
            } else {
                showSnackbar(data.message)
                console.error("Failed to removeGroup", response.statusText);
                // alert("Failed to createGroup. Please try again.");
            }
        } catch (error) {
            console.error("Error during removeGroup:", error);
            // alert("An error occurred. Please try again.");
        }
    }
    async function createGroup() {
        let group = document.querySelector('#group')
        if (group.value == '') { showSnackbar('Invalid Username'); return; }
        try {
            const response = await fetch("/pb-admin/create-user/"+group.value, {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify({group:group.value})
            });
            console.log(response)
            const data = await response.json();

            if (data.ok) {
                // Redirect to the login page after logout
                group.value = ''
                showSnackbar(data.message)
                getGroup()
            } else {
                showSnackbar(data.message)
                console.error("Failed to createGroup", response.statusText);
                // alert("Failed to createGroup. Please try again.");
            }
        } catch (error) {
            console.error("Error during createGroup:", error);
            // alert("An error occurred. Please try again.");
        }
    }


    getGroup()