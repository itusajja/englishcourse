    let defaultCoord = [112.6304, -7.9839];
    let transCoord = ol.proj.fromLonLat(defaultCoord);
    let latestCoord = []
    let latestSelectedUser = {}
    let latestSelectedUserIndex = 0
    let dataLives = [];
    let newLocations = []
    let pageSetting = {}

    async function getLives() {
        newLocations = []
        try {
            const response = await fetch("/pb-admin/get-emergencies", {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
            });
            const data = await response.json();
            pageSetting = window.pageSetting
            dataLives = data
            renderLives(data)
        } catch (error) {
            console.error("Error during getLives:", error);
        }
    }

    getLives()

    function shareTo(group, lat, lon) {
        const shareData = {
            title: 'Shared Location',
            text: `Saudara ${group} sedang dalam keadaan darurat: (${lat},${lon})`,
            url: `https://www.google.com/maps?q=${lat},${lon}`
        };

        const whatsappShareUrl = `https://wa.me/?text=${encodeURIComponent(shareData.text + '\n' + shareData.url)}`;

        window.open(whatsappShareUrl, '_blank').focus();
    }

    const formatDate = (dateInput) => {
        // Ensure dateInput is a Date object
        const date = new Date(dateInput);
        if (isNaN(date)) {
            return 'Invalid Date';
        }

        const d = date.getDate().toString().padStart(2, '0'); // Day
        const m = (date.getMonth() + 1).toString().padStart(2, '0'); // Month
        const y = date.getFullYear(); // Year
        const h = date.getHours().toString().padStart(2, '0'); // Hour
        const i = date.getMinutes().toString().padStart(2, '0'); // Minutes
        const s = date.getSeconds().toString().padStart(2, '0'); // Seconds

        return `${d}/${m}/${y} ${h}:${i}:${s}`;
    };

    function renderLives(data) {
        let output = []
        data.emergencies.sort((a, b) => {
            if (a.group < b.group) return -1;
            if (a.group > b.group) return 1;
            return 0;
        }).forEach((e, i) => {
            let mylocation = ol.proj.toLonLat(e.where);
            newLocations.push({ coords: e.where, title: e.details.group })
            e.formattedDate = formatDate(e.when[e.when.length - 1])

            let share = `<span style="margin-right:5px" onclick="shareTo('${e.details.group}',${mylocation[1].toFixed(4)}, ${mylocation[0].toFixed(4)})" class="label label-success pull-right">Share</span></a>`
            let done = `<span onclick="removeFromLive('${e.details.uuid}','${e.details.group}')" class="label label-danger pull-right">Selesai</span>`
            if(pageSetting.user.id > 1){
                if(pageSetting.staff_dashboard_done == 'off'){
                    done = ''
                }
                if(pageSetting.staff_dashboard_share == 'off'){
                    share = ''
                }
            }


            let item = `<li style="cursor:pointer;padding-left:25px;padding-right:15px" class="item">
                                        <div style="padding: 2px 4px;border-radius: 5px;background: linear-gradient(92deg,#9f0101,#8c2121);background-size: 120% 120%;" class="product-img">
                                            <span class="icon">🔊</span>
                                        </div>
                                        <div class="product-info">
                                            <a href="javascript:void(0)" class="product-title">${e.details.group} (${e.times}x)
                                            `+done+`
                                            `+share+`
                                            <span style="font-size:12px;font-weight:800" class="product-description">
                                                ${mylocation[1].toFixed(4)}, ${mylocation[0].toFixed(4)}
                                            </span>
                                            <span class="product-description" style="font-size:12px;font-weight:800">
                                                ${e.formattedDate}
                                            </span>
                                        </div>
                                    </li>`
            output.push(item)
        })

        if (output.length) {
            document.querySelector('.livesData').innerHTML = output.join("")
        } else {
            document.querySelector('.livesData').innerHTML = "No data available."
        }

        setTimeout(() => {
            updateLocations(newLocations);
        }, 1000)
    }

    async function removeFromLive(uuid, group) {
        if (!confirm(`Apakah kondisi ${group} sudah aman?`)) {
            return
        }
        try {
            const response = await fetch("/pb-admin/remove-live/"+uuid, {
                method: "POST", // Logout is a POST request
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key":"41afcb25c12bfc3fd3a4041b989f11a787b30be97606a017996fa9b3de282831"
                },
                body: JSON.stringify({})
            });
            const data = await response.json();

            if (data.ok) {
                // Redirect to the login page after logout
                showSnackbar(data.message)
                getLives()
            } else {
                showSnackbar(data.message)
                console.error("Failed to fecth", response.statusText);
                // alert("Failed to createGroup. Please try again.");
            }
        } catch (error) {
            console.error("Error during removeFromLive:", error);
            // alert("An error occurred. Please try again.");
        }
    }
    // Coordinates for multiple locations
    let locations = [];

    const defaultCoordinate = ol.proj.fromLonLat(defaultCoord);

    // Transform coordinates and map initialization
    let transformedLocations = locations.map(location => ({
        coords: ol.proj.fromLonLat(location.coords),
        title: location.title,
    }));

    const map = new ol.Map({
        target: 'map',
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM(),
            }),
        ],
        view: new ol.View({
            center: transformedLocations.length > 0 ? transformedLocations[0].coords : defaultCoordinate, // Center on the first location
            zoom: 12,
        }),
    });

    const vectorSource = new ol.source.Vector();

    // Default marker style (red)
    const markerStyle = new ol.style.Style({
        image: new ol.style.Icon({
            anchor: [0.5, 1],
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            scale: 0.5,
            src: 'https://maps.google.com/mapfiles/kml/paddle/red-blank.png',
        }),
    });

    // Green marker style
    const greenMarkerStyle = new ol.style.Style({
        image: new ol.style.Icon({
            anchor: [0.5, 1],
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            scale: .8,
            src: 'https://maps.google.com/mapfiles/kml/paddle/grn-blank.png',
        }),
    });

    // Black marker style
    const blackMarkerStyle = new ol.style.Style({
        image: new ol.style.Icon({
            anchor: [0.5, 1],
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            scale: .3,
            src: 'http://maps.google.com/mapfiles/kml/paddle/blk-blank.png',
        }),
    });
    const overlays = [];

    // Function to add markers and tooltips
    function addMarker(coords, title) {
        const marker = new ol.Feature({
            geometry: new ol.geom.Point(coords),
            name: title,
        });
        marker.setStyle(markerStyle);
        vectorSource.addFeature(marker);

        // Create tooltip for the marker
        const tooltipElement = document.createElement('div');
        // tooltipElement.className = 'tooltip';
        tooltipElement.style.top = '-26px';
        tooltipElement.style.minWidth = '120px';
        tooltipElement.style.fontSize = '10px';
        tooltipElement.style.textAlign = 'center';
        tooltipElement.style.position = 'absolute';
        tooltipElement.style.padding = '2px';
        tooltipElement.style.backgroundColor = 'white';
        tooltipElement.style.border = '1px solid black';
        tooltipElement.style.transform = 'translate(-50%, -100%)';
        tooltipElement.innerHTML = title;

        const overlay = new ol.Overlay({
            element: tooltipElement,
            positioning: 'bottom-center',
            stopEvent: false,
        });

        overlay.setPosition(coords);
        map.addOverlay(overlay);
        overlays.push(overlay);
        return marker;
    }

    // Add all locations to the map
    transformedLocations.forEach(location => {
        addMarker(location.coords, location.title);
    });

    const vectorLayer = new ol.layer.Vector({
        source: vectorSource,
    });
    map.addLayer(vectorLayer);

    // Function to update locations dynamically
    function updateLocations(newLocations) {
        // Clear existing markers and overlays
        overlays.forEach(overlay => map.removeOverlay(overlay));
        vectorSource.clear();
        overlays.length = 0;

        // Update the location list
        locations = newLocations;

        // Transform and add new locations
        transformedLocations = locations.map(location => ({
            coords: location.coords,
            title: location.title,
        }));

        if (transformedLocations.length > 0) {
            transformedLocations.forEach(location => {
                addMarker(location.coords, location.title);
            });

            // Update the map view if needed
            if (transformedLocations.length > 0) {
                map.getView().setCenter(transformedLocations[0].coords);
            }
        } else {
            // Set a default center and zoom if there are no locations
            map.getView().setCenter(ol.proj.fromLonLat(defaultCoord)); // Example: Surabaya coordinates
            map.getView().setZoom(10); // Default zoom level
        }


    }

    // // Example usage
    // setTimeout(() => {
    //     const newLocations = [
    //     ];
    //     updateLocations(newLocations);
    // }, 5000);

    // Handle click event to toggle marker styles and zoom
    map.on('singleclick', event => {
        // Reset all markers to red
        vectorSource.getFeatures().forEach(feature => {
            feature.setStyle(markerStyle);
        });

        // Change the clicked marker to green and zoom into it with a smooth transition
        map.forEachFeatureAtPixel(event.pixel, feature => {
            if (feature) {
                // Set the clicked marker to green
                feature.setStyle(greenMarkerStyle);

                // Get the feature's coordinates
                const coordinates = feature.getGeometry().getCoordinates();

                // Smooth zoom-in transition
                map.getView().animate({
                    center: coordinates,
                    duration: 1000, // Animation duration in milliseconds
                    zoom: 15 // Adjust the zoom level as needed
                });
            }
        });
    });

    // Change cursor to pointer when hovering over a marker
    map.on('pointermove', function(event) {
        const pixel = map.getEventPixel(event.originalEvent);
        const hit = map.hasFeatureAtPixel(pixel);

        if (hit) {
            // Change the cursor to pointer when hovering over a marker
            map.getTargetElement().style.cursor = 'pointer';
        } else {
            // Reset cursor to default when not hovering over a marker
            map.getTargetElement().style.cursor = '';
        }
    });