function showSnackbar(message) {
    var snackbar = document.getElementById("snackbar");
    var input = document.getElementById("pin");
    snackbar.className = "show";
    snackbar.innerHTML = message
    setTimeout(function() { dismissSnackbar() }, 3000);
}

function dismissSnackbar() {
    var snackbar = document.getElementById("snackbar");
    snackbar.className = "";
}